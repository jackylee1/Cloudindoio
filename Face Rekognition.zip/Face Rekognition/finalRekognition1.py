def lambda_handler(event, context):
	import boto3
	import json
	import decimal
	    
	    
	s3 = boto3.resource('s3')
	
	bucket_name = event['Records'][0]['s3']['bucket']['name']
	file_key = event['Records'][0]['s3']['object']['key']
	    
	BUCKET1 = bucket_name
	KEY_TARGET = file_key
	    
	dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
	table = dynamodb.Table('Table_name')
	    
	class DecimalEncoder(json.JSONEncoder):
	    def default(self, o):
	        if isinstance(o, decimal.Decimal):
	            if o % 1 > 0:
	                return float(o)
	            else:
	                return int(o)
	        return super(DecimalEncoder, self).default(o)
	    
	def compare_faces(bucket, key, bucket_target, key_target, threshold=80, region="us-east-1"):
	    rekognition = boto3.client("rekognition", region)
	    response = rekognition.compare_faces(
	        SourceImage={
	            "S3Object": {
	                "Bucket": bucket,
	                "Name": key,
	            }
	        },
	        TargetImage={
	            "S3Object": {
	                "Bucket": bucket_target,
	                "Name": key_target,
	            }
	        },
	        SimilarityThreshold=threshold,
	    )
	    return response['SourceImageFace'], response['FaceMatches']
	        
	        
	BUCKET = s3.Bucket("target_bucket_name")
	    
	for image in BUCKET.objects.all():
	    KEY_SOURCE = image.key
	    #print(KEY_SOURCE)
	        
	    source_face, matches = compare_faces(BUCKET1, KEY_TARGET, BUCKET.name, KEY_SOURCE)
	        
	    source1 = "Source Face ({Confidence})".format(**source_face)
	    print(source1)
	# one match for each target face
	    for match in matches:
	        target1= "Target Face ({Confidence})".format(**match['Face'])
	        print(target1)
	        similarity = format(match['Similarity'])
	        print(similarity)
	    
	        response = table.put_item(
	            Item={
	                'similarity':decimal.Decimal(similarity),
	                'info': {
	                'plot':"Nothing happens at all.",
	                    'rating': decimal.Decimal(0)
	                }
	            }
	            )
	                    #print("PutItem succeeded:")
	                    #print(json.dumps(response, indent=4, cls=DecimalEncoder))
